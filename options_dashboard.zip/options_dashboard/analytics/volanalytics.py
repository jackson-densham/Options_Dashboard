import pandas as pd
import numpy as np

class VolModels:
    def rolling_realized(self, history):
        history = pd.DataFrame(history)
        sigma = history.rolling(window=20).std() * np.sqrt(252)
        return sigma
    
    def ewma(self, history):
        history = pd.DataFrame(history)
        sigma = history.ewm(span=20).std() * np.srqt(252)
        return sigma

    def garch():
        pass
import pandas as pd
from options_dashboard.data.data import get_spot_and_history, get_option_chain
from options_dashboard.pricing.blackscholes import BlackScholesPricer

def iv_points(ticker, contract, market):
    spot = get_spot_and_history(ticker)
    chain = get_option_chain(ticker)
    iv_df = pd.DataFrame(columns=["DTE", "Strike", "IV"])
    pricer = BlackScholesPricer()

    # Loop through each contract to add it's DTE, strike, and IV to the data frame
    for i in range(len(chain)):
        expiry = chain['expiry'].loc[i]
        strike = chain['strike'].loc[i]
        iv = pricer.implied_vol(contract, market, market_price)
